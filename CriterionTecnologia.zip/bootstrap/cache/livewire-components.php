<?php return array (
  'cadastro-produto' => 'App\\Http\\Livewire\\CadastroProduto',
  'lista-beer' => 'App\\Http\\Livewire\\ListaBeer',
);