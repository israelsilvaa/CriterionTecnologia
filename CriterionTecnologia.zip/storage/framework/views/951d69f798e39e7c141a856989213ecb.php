<?php $__env->startSection('titulo', 'SP-Detalhes do produto'); ?>

<?php $__env->startSection('conteudo'); ?>


    <main class="flex-fill">
        <div class="container">
            <div class="row g-3">
                <div class="col-12 col-sm-6">
                    <img src="<?php echo e(url("storage/{$modelo->imagem_card}")); ?>" class="img-thumbnail mt-2 bg-dark" id="imgProduto">
                    
                    <br class="clearfix">
                    
                </div>
                <div class="col-12 col-sm-6 text-white">
                    <h1><?php echo e($modelo->produto); ?></h1>
                    <div class="row">

                        <div class="col-sm-12 col-md-8  ">
                            <small>Marca: <?php echo e($modelo->marca); ?></small>
                        </div>
                        <div class="col-sm-12 col-md-8  ">
                            <small>modelo: <?php echo e($modelo->modelo); ?></small>
                        </div>
                        <div class="col-sm-12 col-md-8  ">
                            <small>Interface: <?php echo e($modelo->tipo); ?></small>
                        </div>
                        <div class="col-sm-12 col-md-8  ">
                            <small>Capacidade: <?php echo e($modelo->capacidade); ?></small>
                        </div>
                        <div class="col-sm-12 col-md-8 ">
                            <small>Performance de referência: até <?php echo e($modelo->leitura); ?> para leitura e
                                <?php echo e($modelo->escrita); ?> para gravação</small>
                        </div>
                        <div class="col-sm-12 col-md-8 ">
                            <small>Geração: <?php echo e($modelo->geracao); ?></small>
                        </div>
                        <div class="col-sm-12 col-md-8 ">
                            <small>Aplicação: <?php echo e($modelo->aplicacao); ?></small>
                        </div>
                        <div class="col-sm-12 col-md-8 ">
                            <small>dimensões:
                                <?php echo e($modelo->altura); ?><?php echo e($modelo->unidade_medida); ?> x
                                <?php echo e($modelo->largura); ?><?php echo e($modelo->unidade_medida); ?> x
                                <?php echo e($modelo->profundidade); ?><?php echo e($modelo->unidade_medida); ?>

                            </small>
                        </div>
                    </div>

                    <?php if($disponibilidade): ?>
                        <p class="text-center mt-4">
                            
                            <a href="https://wa.me/55091980175325?text=olá, o <?php echo e($modelo->produto); ?> ainda está dipsonivel?"
                                class="btn btn-lg btn-success mb-3 mb-xl-0 me-2">
                                <i class="bi-whatsapp"></i> Solicitar via whatsapp
                            </a>
                            
                        </p>
                    <?php else: ?>
                        <p class="text-center mt-4">
                            <a href="#" class="btn btn-lg btn-warning disabled mb-3 mb-xl-0 me-2">
                                <i class="fa-solid fa-triangle-exclamation"></i>
                                Reabastecendo estoque.
                            </a>
                            
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <script>
                function trocarImagem(el) {
                    var imgProduto = document.getElementById("imgProduto");
                    imgProduto.src = el.src;
                }
            </script>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/visitante/produto.blade.php ENDPATH**/ ?>