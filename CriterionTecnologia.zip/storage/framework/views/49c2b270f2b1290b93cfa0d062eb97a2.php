<?php $__env->startSection('titulo', 'Modelos'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container bg-secondary mt-5 rounded-5">
        <div class="row justify-content-center">
            <div class="col-auto ">
                <img src="<?php echo e(asset('/images/logo_1.png')); ?>" width="190px" height="70px" alt="" />
            </div>
        </div>
        <div class="row">
            <h1 class="text-center">Modelos e especificações </h1>

            <div class="col mt-4">
                <?php if(isset($modelos)): ?>
                    <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ssd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4><?php echo e($ssd->nome_produto); ?> </h4>
                        <div class="table-responsive">
                            <table class="table table-dark">
                                <thead>
                                    <tr>
                                        <th scope="col">Modelo</th>
                                        <th scope="col">Capacidade</th>
                                        <th scope="col">Tipo</th>
                                        <th scope="col">Leitura/escrita</th>
                                        <th scope="col">Aplicação</th>
                                        <th scope="col">Geração</th>
                                        <th scope="col">Preço</th>
                                        <th scope="col">Disponibilidade</th>
                                    </tr>
                                </thead>
                                <tbody class="table-group-divider">
                                    <tr>
                                        <td><?php echo e($ssd->nome_modelo); ?></td>
                                        <td><?php echo e($ssd->capacidade); ?></td>
                                        <td><?php echo e($ssd->tipo); ?></td>
                                        <td><?php echo e($ssd->leitura); ?>-<?php echo e($ssd->escrita); ?></td>
                                        <td><?php echo e($ssd->aplicacao); ?></td>
                                        <td><?php echo e($ssd->geracao); ?></td>
                                        <td>R$<?php echo e($ssd->preco); ?></td>
                                        <td><?php echo e($ssd->disponibilidade); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="row col-6 offset-3 mt-4 ">
            <footer class="text-danger text-center">
                <a href="/" class="link link-secondary text-dark"> Voltar</a>
            </footer>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/visitante/modelos_antigo.blade.php ENDPATH**/ ?>