<?php $__env->startSection('titulo', 'Formas de entrega'); ?>

<?php $__env->startSection('conteudo'); ?>

    <main class="flex-fill">
        <div class="container">
            <div class="text-white">
                <?php if(isset($produto)): ?>
                    <?php echo e($produto); ?>

                <?php endif; ?>
        </div>
    </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/visitante/teste.blade.php ENDPATH**/ ?>