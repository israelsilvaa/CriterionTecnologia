<div class="row col-6 offset-3 mt-4">
    <footer class="text-center">
        <a href="<?php echo e(route('login')); ?>" class="link link-dark text-decoration-none fw-bold"> admin</a> |
        <span>Desenvolvido por <a class="link link-dark text-decoration-none fw-bold" href="https://www.linkedin.com/in/israel-silva-472b21214/"> IsraelSilva</a></span>
    </footer>
</div><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/visitante/layout/_partials/footerContato.blade.php ENDPATH**/ ?>