<?php $__env->startSection('titulo', 'Formas de entrega'); ?>

<?php $__env->startSection('conteudo'); ?>

    <main class="flex-fill">
        <div class="container">
            <div class="text-white">
                <h1>Formas de entrega</h1>
                <hr>
                <h4>
                    Facilitada
                </h4>
                <p >
                    Atualmente trabalhamos com entrega <b>facilitada</b>, onde o cliente pode receber seu produto
                    gratuitamente em um local público, abaixo está listado alguns locais comuns e seguros para buscar seu
                    produto.
                </p>
                <ul>
                    <li>UFPA</li>
                    <li>São Brás</li>
                    <li>Bosque Rodrigues halvez</li>
                    <li>Shopping Castanheira</li>
                    <li>Shopping Metrópole</li>
                    <li>Shopping Pátio Belém</li>
                    <li>Havan Ananindeua</li>
                    <li>Prefeitura de
                        Ananindeua</li>
                    <li> Praça matriz de Marituba</li>
                </ul>
            </div>
        </div>
    </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/visitante/formas_de_entrega.blade.php ENDPATH**/ ?>