<div>
    <div class="row justify-content-center">
        <h2 class="text-center">Novo produto</h2>
        <div class="col-md-8 ">

            <h6 class="text-center">Informações do produto</h6>
            <form action="<?php echo e(route('admin.cadastroProduto')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="input-group mb-1">
                    <span class="input-group-text" id="basic-addon1">Número de série</span>
                    <input type="text" class="form-control" name="numero_serie" id=""
                        placeholder="11155577799 " aria-label="nome_produto" aria-describedby="basic-addon1">
                </div>

                <div class="row">
                    <div class="col-md-6 col-sm-12">

                        <label for="nome_marca">Marca</label>
                        <select class="form-select form-select-sm"
                        name="nome_marca" 
                        wire:model="marca_id" 
                        wire:change="filtroModeloPorMarcaId" 
                        >
                            <option value="0" class="text-danger" selected>Marca</option>
                            <?php $__currentLoopData = $marca->all(['id', 'nome_marca']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($marca->id); ?>">
                                    <?php echo e($marca->nome_marca); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select><br />
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <label for="nome_modelo">Modelo</label>
                        <select class="form-select form-select-sm" name="nome_modelo" id="">
                            <option value="0" selected><span class="text-danger">Modelos</span></option>
                            <?php if(isset($modelos)): ?>
                                <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($modelo->id); ?>"><?php echo e($modelo->nome_modelo); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="">
                                    --
                                </option>
                            <?php endif; ?>
                        </select><br />
                    </div>
                </div>

                <h6 class="text-center">Informações de importação</h6>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="input-group mb-1">
                            <span class="input-group-text" id="basic-addon1">Preço</span>
                            <input type="decimal" class="form-control" name="preco_importacao" id=""
                                placeholder="R$180.50 " aria-label="nome_produto" aria-describedby="basic-addon1">
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-12">
                        <div class="input-group mb-1">
                            <span class="input-group-text" id="basic-addon1">Número do Lote</span>
                            <input type="text" class="form-control" name="lote" id=""
                                placeholder="2/2023 " aria-label="numero_lote" aria-describedby="basic-addon1">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="input-group mb-1">
                            <span class="input-group-text" id="basic-addon1">Pedido</span>
                            <input type="date" class="form-control" name="data_pedido" aria-label="nome_produto"
                                aria-describedby="basic-addon1">
                        </div>

                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="input-group mb-1">
                            <span class="input-group-text" id="basic-addon1">Chegada</span>
                            <input type="date" class="form-control" name="data_chegada" aria-label="nome_produto"
                                aria-describedby="basic-addon1">
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-block">cadastrar</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/livewire/cadastro-produto.blade.php ENDPATH**/ ?>