

<?php $__env->startSection('titulo', 'Painel'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container bg-secondary mt-5 rounded-4">
        <div class="row justify-content-center">
            <div class="col-auto ">
                <img src="<?php echo e(asset('/images/logo_1.png')); ?>" width="190px" height="70px" alt="" />
            </div>
        </div>

        <div>
            <h1>PAINEL CLIENTE</h1>
        </div>

        <div class="row col-6 offset-3 mt-4 ">
            <footer class="text-danger text-center">
                <a href="/" class="link link-info text-dark"> Sair</a>
            </footer>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cliente.layout.basico2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/cliente/painel.blade.php ENDPATH**/ ?>