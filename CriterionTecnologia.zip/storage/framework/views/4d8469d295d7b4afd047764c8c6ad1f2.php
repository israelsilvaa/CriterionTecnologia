<?php $__env->startSection('titulo', 'Cadastrar Produto'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container bg-secondary text-center  mt-5 rounded-5">
        <div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cadastro-produto')->html();
} elseif ($_instance->childHasBeenRendered('ELRZ1ir')) {
    $componentId = $_instance->getRenderedChildComponentId('ELRZ1ir');
    $componentTag = $_instance->getRenderedChildComponentTagName('ELRZ1ir');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ELRZ1ir');
} else {
    $response = \Livewire\Livewire::mount('cadastro-produto');
    $html = $response->html();
    $_instance->logRenderedChild('ELRZ1ir', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/admin/cadastroProduto.blade.php ENDPATH**/ ?>