<?php $__env->startSection('titulo', 'Login'); ?>

<?php $__env->startSection('conteudo'); ?>

    <main class="form-signin w-100 m-auto ">
        <form action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <img class="mb-2" src="<?php echo e(url('storage/modelos/logo.png')); ?>" alt="" width="315" height="100">
            <h1 class="h3 mb-3 fw-normal text-success">Login</h1>

            <div class="form-floating text-dark">
                <input type="email" value="<?php echo e(old('usuario')); ?>" name="usuario" class="form-control" id="floatingInput"
                    placeholder="name@example.com">
                <?php if($errors->has('usuario')): ?>
                    <span class="errors text-danger"> <?php echo e($errors->first('usuario')); ?></span>
                <?php endif; ?>
                <label for="floatingInput">Usuário</label>
            </div>
            <div class="form-floating text-dark">
                <input type="password" name="senha" value="<?php echo e(old('senha')); ?>" class="form-control" id="floatingPassword"
                    placeholder="Password">
                <label for="floatingPassword">Senha</label>
            </div>
            <?php if($errors->has('senha')): ?>
                <span class="errors text-danger"> <?php echo e($errors->first('senha')); ?></span>
            <?php endif; ?>


            <button class="btn btn-primary w-100 py-2" type="submit">Entrar</button>
            <div class="row mt-5 text-center">
                <div class="col-12">
                    <a class="link text-white" href="/">Voltar</a>
                </div>
            </div>
            <p class="mt-5 mb-3 text-body-white text-center">CT - 2023–2023</p>
        </form>
    </main>
    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.loginBasico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/admin/login.blade.php ENDPATH**/ ?>