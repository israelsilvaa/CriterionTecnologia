<?php $__env->startSection('titulo', 'Modelos'); ?>

<?php $__env->startSection('conteudo'); ?>

    <main class="flex-fill">
        <div class="container">
            <div class="row g-3 text-white">
                <h4>Modelos e disponibilidade</h4>
                <?php if(isset($modelos)): ?>
                    <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ssd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ssd->disponibilidade): ?>
                            <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2">
                                <div class="card text-center text-white  cor-texto-card bg-dark">
                                    <a href="#" class="position-absolute end-0 p-2 text-danger">
                                        <i class="bi bi-suit-heart" style="font-size: 20px; line-height: 20px"></i>
                                    </a>
                                    <img src="<?php echo e(url("storage/{$ssd->imagem_card}")); ?>" class="card-img-top" alt="...">
                                    <div class="card-header text-success">
                                        R$<?php echo e($ssd->preco); ?> à vista
                                    </div>
                                    <div class="card-body">
                                        <h6 class="card-title"><?php echo e($ssd->produto); ?></h6>
                                        <p class="card-text truncar-3l"><?php echo e($ssd->modelo); ?>, leitura:<?php echo e($ssd->leitura); ?>, escrita: <?php echo e($ssd->escrita); ?>, para <?php echo e($ssd->aplicacao); ?></p>
                                    </div>
                                    <div class="card-footer">
                                        <a href=" produto/<?php echo e($ssd->modelo_id); ?>/<?php echo e($ssd->disponibilidade); ?>" class="btn btn-success mt-2 d-block">Ver mais</a><br>
                                        <small class="text-success"><?php echo e($ssd->disponibilidade); ?> unidades disponiveis</small>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2">
                                <div class="card text-center text-white bg-dark">
                                    <a href="#" class="position-absolute end-0 p-2 text-danger">
                                        <i class="bi bi-suit-heart" style="font-size: 20px; line-height: 20px"></i>
                                    </a>
                                    
                                    <img src="<?php echo e(url("storage/{$ssd->imagem_card}")); ?>" class="card-img-top" alt="...">
                                    <div class="card-header">
                                        R$ <?php echo e($ssd->preco); ?> à vista
                                    </div>
                                    <div class="card-body">
                                        <h6 class="card-title"><?php echo e($ssd->produto); ?></h6>
                                        <p class="card-text truncar-3l"><?php echo e($ssd->modelo); ?>, leitura:<?php echo e($ssd->leitura); ?>, escrita: <?php echo e($ssd->escrita); ?>, para <?php echo e($ssd->aplicacao); ?></p>
                                    </div>
                                    <div class="card-footer">
                                        <a href=" produto/<?php echo e($ssd->modelo_id); ?>/<?php echo e($ssd->disponibilidade); ?>" class="btn btn-secondary  mt-2 d-block">
                                            <small>ver mais</small>
                                        </a><br>
                                        <small class="text-danger">
                                            <b>Produto esgotado</b>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>


            </div>

            <hr class="mt-3">

        </div>
    </main>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/visitante/modelos.blade.php ENDPATH**/ ?>