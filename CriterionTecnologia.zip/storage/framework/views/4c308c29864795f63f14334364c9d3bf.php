<?php $__env->startSection('titulo', 'Painel'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="container bg-secondary mt-5 rounded-4">
        
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h1 class="text-center">Painel</h1>
                <h4>Produtos</h4>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th scope="col">Marca</th>
                                <th scope="col">Nome</th>
                                <th scope="col">Modelo</th>
                                <th scope="col">Capacidade</th>
                                <th scope="col">Tipo</th>
                                <th scope="col">N/S</th>
                                <th scope="col">Aplicação</th>
                                <th scope="col">Geração</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider">
                            <?php if(isset($listaProdutos)): ?>
                                <?php $__currentLoopData = $listaProdutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($produto->marca); ?></th>
                                        <th><?php echo e($produto->nome); ?></th>
                                        <td><?php echo e($produto->modelo); ?></td>
                                        <td><?php echo e($produto->capacidade); ?></td>
                                        <td><?php echo e($produto->tipo); ?></td>
                                        <td><?php echo e($produto->numero_serie); ?></td>
                                        <td><?php echo e($produto->aplicacao); ?></td>
                                        <td><?php echo e($produto->geracao); ?></td>
                                        <td><?php echo e($produto->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <h4>Ultimas Vendas</h4>
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th scope="col">Cliente</th>
                                <th scope="col">N/S</th>
                                <th scope="col">valor</th>
                                <th scope="col">lucro</th>
                                <th scope="col">compra</th>
                                <th scope="col">Vencimento</th>
                                <th scope="col">Resumo</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider">
                            <?php if(isset($listaVendas)): ?>
                                <?php $__currentLoopData = $listaVendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($venda->cliente); ?></th>
                                        <td><?php echo e($venda->numero_serie); ?></td>
                                        <td><?php echo e($venda->preco_venda); ?></td>
                                        <td><?php echo e($venda->lucro); ?></td>
                                        <td><?php echo e($venda->data_venda); ?></td>
                                        <td><?php echo e($venda->data_garantia); ?></td>
                                        <td><?php echo e($venda->observacao); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/admin/painel.blade.php ENDPATH**/ ?>