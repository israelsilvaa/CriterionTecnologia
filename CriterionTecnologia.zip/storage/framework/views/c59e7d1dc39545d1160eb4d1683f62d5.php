<?php $__env->startSection('titulo', 'Garantia'); ?>

<?php $__env->startSection('conteudo'); ?>
    <main class="flex-fill">
        <div class="container">
            <div class="row g-3 ">
                <h1 class="text-center text-white">Garantia</h1>
                <hr class="text-white">
                <form method="post" action="<?php echo e(route('visitante.garantia')); ?>" class="text-center text-white ">
                    <?php echo csrf_field(); ?>

                    <label for="">Número de série:</label>
                    <input type="text" name="numero_serie" id=""
                    <?php if(isset($produto->numero_serie)): ?> 
                        value="<?php echo e($produto->numero_serie); ?>" 
                    <?php elseif(old('numero_serie')): ?>
                        value="<?php echo e(old('numero_serie')); ?>" 
                    <?php else: ?>
                        placeholder="NV3000-500GB"
                    <?php endif; ?>
                    >
                        <button type="submit" class="btn btn-success">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    </button><br>
                    <?php if($errors->all()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-12 col-md-4 mt-4">
                    <?php if(isset($venda)): ?>
                        <img src="<?php echo e(url("storage/{$produto->imagem_card}")); ?>" class="img-thumbnail bg-dark"
                            id="imgProduto">
                    <?php else: ?>
                        <img src="<?php echo e(url('storage/modelos/jDII4Q6znFXoQFqBwQAnKoJ01dBLue1emIAqvnmg.png')); ?>"
                            class="img-thumbnail bg-dark" id="imgProduto">
                    <?php endif; ?>
                    <br class="clearfix">
                    
                </div>

                <div class="col-sm-12 col-md-4 text-white mt-4">
                    <h1>Detalhes do produto</h1>
                    <?php if(isset($venda)): ?>
                        <div class="row text-white">
                            <div class="col-sm-12 col-md-8  ">
                                <small>Marca: <?php echo e($produto->marca); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>modelo: <?php echo e($produto->modelo); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>N/S: <?php echo e($produto->numero_serie); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Interface: <?php echo e($produto->tipo); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Capacidade: <?php echo e($produto->capacidade); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Performance de referência: até <?php echo e($produto->leitura); ?> para leitura e
                                    <?php echo e($produto->escrita); ?> para gravação</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Geração: <?php echo e($produto->geracao); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Aplicação: <?php echo e($produto->aplicacao); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>dimensões: 100,0 mm x 69,9 mm x 7,0 mm</small>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row text-white">
                            <div class="col-sm-12 col-md-8  ">
                                <small>Marca: -</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>modelo: -</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>N/S: -</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Interface: -</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Capacidade: -</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Performance de referência: -</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Geração:-</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Aplicação:-</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>dimensões:-</small>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-sm-12 col-md-4 text-white mt-4 text-white">
                    <h1>Detalhes da venda</h1>
                    <?php if(isset($venda)): ?>
                        <?php
                            $dataGarantia = \Carbon\Carbon::parse($venda->data_garantia);
                            $dataAtual = \Carbon\Carbon::now();
                        ?>
                        <div class="row text-white">
                            <div class="col-sm-12 col-md-8  ">
                                <small>Cliente: <?php echo e($venda->cliente); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8 ">
                                <small>Valor: R$<?php echo e($venda->preco_venda); ?></small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Data da compra:
                                    <?php echo e(\Carbon\Carbon::parse($venda->data_venda)->format('d/m/Y')); ?></small>
                            </div>
                            <?php if($dataGarantia->isBefore($dataAtual)): ?>
                                <div class="col-sm-12 col-md-8">
                                    <small>Data da garantia:
                                        <small class="text-danger">
                                            <?php echo e(\Carbon\Carbon::parse($venda->data_garantia)->format('d/m/Y')); ?>

                                        </small>
                                    </small>
                                </div>
                                <div class="col-sm-12 col-md-8  ">
                                    <small>Status:
                                        <small class="text-danger">Fora da garantia</small>
                                        <i class="fa-solid fa-exclamation" style="color: #db0000;"></i>
                                    </small>
                                </div>
                            <?php else: ?>
                                <div class="col-sm-12 col-md-8  ">
                                    <small>Data da garantia:
                                        <small class="text-success">
                                            <?php echo e(\Carbon\Carbon::parse($venda->data_garantia)->format('d/m/Y')); ?>

                                        </small>
                                    </small>
                                </div>
                                <div class="col-sm-12 col-md-8  ">
                                    <small>Status:
                                        <small class="text-success">Dentro da garantia</small>
                                        <i class="fa-solid fa-check" style="color: #0aae25;"></i>
                                    </small>
                                </div>
                            <?php endif; ?>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Obsevações: <?php echo e($venda->observacao); ?></small>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row text-white">
                            <div class="col-sm-12 col-md-8  ">
                                <small>Cliente: ----</small>
                            </div>
                            <div class="col-sm-12 col-md-8 ">
                                <small>Valor: ----</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Data da compra: ----</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Data da garantia: ----</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Obsevações: ----</small>
                            </div>
                            <div class="col-sm-12 col-md-8  ">
                                <small>Status: ----</small>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <hr class="text-white">
            <div class="row">
                <div class="col-sm-12 col-md-6 text-white mt-4">
                    <p>
                        O que a garantia da loja cobre? <br>
                    <ol>
                        <li>SSD MUITO lento, incompatível com as velocidades referência.</li>
                        <li>SSD em formato RAW.</li>
                        <li>só liga o led, mas não inicia.</li>
                        <li>Não gostei da cor</li>
                    </ol>
                    </p>
                </div>
                <div class="col-sm-12 col-md-6 text-white mt-4">
                    <p>
                        O que NÃO cobre? <br>
                    <ol>
                        <li>máquina não suporta entrada do SSD (m.2, Sata).</li>
                        <li>me arrependi da compra.</li>
                        <li>quero um tamanho maior. </li>
                    </ol>
                    </p>
                </div>
            </div>
        </div>
        
    </main>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RX570\Documents\CriterionTecnologia\resources\views/visitante/garantia.blade.php ENDPATH**/ ?>